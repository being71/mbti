import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Fungsi untuk menambahkan data pengguna ke Firestore dengan UID
  Future<void> registerUser(String name, String dob, String email) async {
    try {
      // Mendapatkan UID dari user yang baru terdaftar
      String userId = FirebaseAuth.instance.currentUser!.uid;
      print("User registered with UID: $userId");

      // Menambahkan data pengguna ke koleksi 'users' dengan UID
      await _firestore.collection('users').doc(userId).set({
        'name': name,
        'dob': dob,
        'email': email,
        'MBTI': "", // Nilai default MBTI
      });

      print("User data saved to Firestore");
    } catch (e) {
      // Menangani kesalahan saat menyimpan data ke Firestore
      print('Error saving user data: ${e.toString()}');
    }
  }

  // Fungsi untuk memperbarui MBTI pengguna di Firestore
  Future<void> updateMBTI(String userId, String personalityType) async {
    try {
      // Memperbarui nilai MBTI pada pengguna dengan userId yang sesuai
      await _firestore.collection('users').doc(userId).update({
        'MBTI': personalityType, // Menyimpan tipe MBTI yang dihitung
      });
      print("MBTI updated successfully for user $userId");
    } catch (e) {
      // Menangani kesalahan saat memperbarui data MBTI
      print('Error updating MBTI: ${e.toString()}');
    }
  }
}
